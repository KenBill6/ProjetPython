import os

from flask_cors import *

# importer Flask
from flask import Flask, abort, jsonify, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy  # importer SQLAlchemy
#import urllib.parse
from urllib.parse import quote_plus
from dotenv import load_dotenv  # permet d'importer les variables d'environnement
load_dotenv()
#from flask_migrate import Migrate

app = Flask(__name__)  # Créer une instance de l'application
#pg_pswrd = os.environ.get('pgpswrd')

#otdepasse = quote_plus(os.getenv('1234'))

#app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:{}@localhost:5432/todog2".format(1234)
app.config['SQLALCHEMY_DATABASE_URI']='postgresql://postgres:1234@localhost:5432/bibliotheque'
# connexion à la base de données
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

bd = SQLAlchemy(app)  # Créer une instance de BD

#CORS(app)
#CORS(app, resources={r"/api/*": {"origins": "*"}})

# CORS Headers


#@app.after_request
#def after_request(response):
 #   response.headers.add('Access-Control-Allow-Headers',
  #                       'Content-Type,Authorization,true')
   # response.headers.add('Access-Control-Allow-Methods',
    #                     'GET,PUT,POST,DELETE,OPTIONS')
    #return response


class Livre(bd.Model):
    __tablename__='livre'
    id_livres=bd.Column(bd.Integer(),primary_key=True)
    isbn=bd.Column(bd.String(50),nullable=False)
    titre=bd.Column(bd.String(50),nullable=False)
    date_publication=bd.Column(bd.DateTime,nullable=False)
    auteur=bd.Column(bd.String(50),nullable=False)
    editeur=bd.Column(bd.String(50),nullable=False)
    Categorie_id=bd.Column(bd.Integer(),bd.ForeignKey('categorie.id_catg'),nullable=False)
    
    def __init__(self,isbn,titre,date_publication,auteur,editeur,categorie_id):   
        self.isbn=isbn
        self.titre=titre
        self.date_publication=date_publication
        self.auteur=auteur
        self.editeur=editeur
        self.Categorie_id=categorie_id

class Categorie(bd.Model):
    __tablename__='categorie'
    id_catg=bd.Column(bd.Integer(),primary_key=True)
    Libelle_Categorie=bd.Column(bd.String(50),nullable=False)
    link=bd.relationship('Livre',backref='categorie',lazy=True)

    def __init__(self,Libelle_Categorie):
        self.Libelle_Categorie=Libelle_Categorie

    def insert(self):
        bd.session.add(self)
        bd.session.commit()

    def update(self):
        bd.session.commit()

    def delete(self):
        bd.session.delete(self)
        bd.session.commit()

    def format(self):
       return {
            'isbn':self.isbn,
            'titre':self.titre,
            'date_publication':self.date_publication,
            'auteur':self.auteur,
            'editeur':self.editeur,
            'categorie_id':self.Categorie_id
        }


bd.create_all()


@app.route('/api')
def api():
    return jsonify({
        'nom': 'HOUNSINOU',
        'prenom': 'Kenny'
    })

#################################################
#           Liste des Livres
####################################################


@app.route('/livres')
def get_all_livres():
    livres = Livre.query.all()
    livres = [p.format() for p in livres]
    return jsonify(
        {
            'success': True,
            'livres': livres,
            'nombre': len(Livre.query.all())}
    )

#################################################
#           Liste des Categories
####################################################


@app.route('/categorie')
def get_all_categorie():
    categorie = Categorie.query.all()
    categorie = [p.format() for p in categorie]
    return jsonify(
        {
            'success': True,
            'categorie': categorie,
            'nombre': len(Categorie.query.all())}
    )


#################################################
#           selectioner un livre
####################################################
@app.route('/livres/<int:livre_id>')
def one_livre(livre_id):
    try:
        livre = Livre.query.get(livre_id)
        if livre is None:
            abort(404)
        else:
            return jsonify({
                'success': True,
                'id_livres':livre_id,
                'livre': livre_id.format()
            })
    except:
        abort(400)

#################################################
#           selectioner une categorie
####################################################
@app.route('/categories/<int:categorie_id>')
def one_categorie(categorie_id):
    try:
        categorie = Categorie.query.get(categorie_id)
        if categorie is None:
            abort(404)
        else:
            return jsonify({
                'success': True,
                'id_categorie':categorie_id,
                'categorie': categorie_id.format()
            })
    except:
        abort(400)

#################################################
#           Ajouter un livre
####################################################


@app.route('/livres', methods=['POST'])
def add_livre():
    body = request.get_json()
    new_isbn = body.get('isbn', None)
    new_titre=body.get('titre', None)
    new_date_publication=body.get('date_publication', None)
    new_auteur=body.get('auteur', None)
    new_editeur=body.get('editeur', None)
    new_categorie_id=body.get('categorie_id', None)
   
    livre = Livre(isbn=new_isbn,titre=new_titre,date_publication=new_date_publication,auteur=new_auteur,editeur=new_editeur,categorie_id=new_categorie_id)
    livre.insert()
    livres = Livre.query.all()
    livres_formatted = [p.format() for p in livres]
    return jsonify({
        'success': True,
        'created': Livre.id,
        'livres': livres_formatted,
        'total_livres': len(Livre.query.all())
    })


#################################################
#           Ajouter une categorie
####################################################


@app.route('/categorie', methods=['POST'])
def add_categorie():
    body = request.get_json()
    new_Libelle_Categorie=body.get('categorie_id', None)
   
    categorie = Livre(Libelle_Categorie=new_Libelle_Categorie)
    categorie.insert()
    categorie = Livre.query.all()
    categorie_formatted = [p.format() for p in categorie]
    return jsonify({
        'success': True,
        'created': Categorie.id,
        'categorie': categorie_formatted,
        'total_categorie': len(Categorie.query.all())
    })


#################################################
#           Modifier un livre
####################################################


@app.route('/livres/<int:livre_id>', methods=['PATCH'])
def update_livre(livre_id):
    body = request.get_json()
    try:
        mon_livre = Livre.query.filter(Livre.id == livre_id).one_or_none()
        if mon_livre is None:
            abort(404)
        if 'isbn' in body and 'titre' in body and 'date_publication' in body and'auteur' in body and'editeur' in body and'categorie_id' in body:
            mon_livre.isbn = body.get('isbn')
            mon_livre.titre = body.get('titre')
            mon_livre.date_publication = body.get('date_publication')
            mon_livre.auteur = body.get('auteur')
            mon_livre.editeur = body.get('editeur')
            mon_livre.categorie_id = body.get('categorie_id')
            
        mon_livre.update()
        return jsonify({
            'success': True,           
            'id_livres': mon_livre.id,
            'livre_modifie': mon_livre.format()
        })
    except:
        abort(400)


#################################################
#           Modifier une categorie
####################################################


@app.route('/categorie/<int:categorie_id>', methods=['PATCH'])
def update_categorie(categorie_id):
    body = request.get_json()
    try:
        ma_categorie = Categorie.query.filter(Categorie.id == categorie_id).one_or_none()
        if ma_categorie is None:
            abort(404)
        if 'Libelle_Categorie' in body :
            ma_categorie.isbn = body.get('Libelle_Categorie')
           
        ma_categorie.update()
        return jsonify({
            'success': True,           
            'id_catg': ma_categorie.id,
            'categorie_modifie': ma_categorie.format()
        })
    except:
        abort(400)

#################################################
#           Supprimer un livre
####################################################
@app.route('/livres/<int:livre_id>', methods=['DELETE'])
def supprimer_livre(livre_id):
    try:
        mon_livre= Livre.query.get(livre_id)
        if mon_livre is None:
            abort(404)
        else:
            mon_livre.delete()
            return jsonify({
                "success": True,
                "deleted_id": livre_id,
                "total_livres": len(Livre.query.all())
            })
    except:
        abort(400)
    finally:
        bd.session.close()
        
#################################################
#           Supprimer une categorie
####################################################
@app.route('/categorie/<int:categorie_id>', methods=['DELETE'])
def supprimer_categorie(categorie_id):
    try:
        ma_categorie= Categorie.query.get(categorie_id)
        if ma_categorie is None:
            abort(404)
        else:
            ma_categorie.delete()
            return jsonify({
                "success": True,
                "deleted_id": categorie_id,
                "total_categorie": len(Categorie.query.all())
            })
    except:
        abort(400)
    finally:
        bd.session.close()
        

#ici on fait un get et la ressource 
#n'existe pas http://localhost:5000/livres/200
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "success": False, 
        "error": 404,
        "message": "Not found"
        }), 404
    
@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "success": False, 
        "error": 500,
        "message": "Internal server error"
        }), 500
    
@app.errorhandler(400)
def bad_request(error):
    return jsonify({
        "success": False, 
        "error": 400,
        "message": "Bad Request"
        }), 400